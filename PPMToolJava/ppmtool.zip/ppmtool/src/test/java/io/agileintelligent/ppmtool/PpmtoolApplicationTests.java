package io.agileintelligent.ppmtool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PpmtoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
